const landing = (props) => {
    return (
      <div>
        <div className={"max-w-screen overflow-hidden"}></div>
      </div>
    );
  };
  
  export default landing;
  